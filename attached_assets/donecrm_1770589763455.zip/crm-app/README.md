# DoneCRM - Gestion Business Simplifiée

![DoneCRM](https://img.shields.io/badge/Status-Production%20Ready-success)
![Version](https://img.shields.io/badge/Version-1.0.0-orange)

Une application CRM moderne et intuitive pour gérer votre activité de création de sites web.

## 🚀 Fonctionnalités

### 📊 Dashboard Complet
- **KPIs en temps réel** : MRR, ARR, CA, Marge
- **Graphiques visuels** : Répartition du CA par secteur
- **Suivi des coûts** : Meta, Done, Replit, Domaines
- **Taux de conversion** : Lead → Prospect → Client

### 🎯 Pipeline Visuel
- **Drag & Drop** : Déplacez vos clients entre les étapes
- **4 statuts** : Leads, Prospects, Clients, Churned
- **Vision claire** : Voyez instantanément où en est chaque prospect

### 👥 Gestion Clients
- **Fiches complètes** : Nom, site, secteur, finances, notes
- **Recherche & filtres** : Trouvez rapidement vos clients
- **Édition rapide** : Modifiez les informations en un clic

### 💰 Suivi Financier
- **Revenus** : Montants de vente et abonnements mensuels
- **Coûts détaillés** : Replit, domaines, autres frais
- **Calcul automatique** : Marge et rentabilité

### 📥 Import/Export
- **Import Excel** : Importez votre fichier Gestion_V1.xlsx
- **Export Excel** : Téléchargez vos données à tout moment
- **Sauvegarde auto** : Données enregistrées dans le navigateur

## 🛠️ Installation sur Replit

### Option 1 : Import ZIP (Recommandé)

1. Allez sur [Replit.com](https://replit.com)
2. Cliquez sur **"+ Create Repl"**
3. Sélectionnez **"Import from GitHub"** ou **"Upload files"**
4. Uploadez le fichier `donecrm.zip`
5. Cliquez sur **"Import"**
6. Appuyez sur **"Run"**
7. Votre CRM est prêt ! 🎉

### Option 2 : Création manuelle

1. Créez un nouveau Repl **HTML, CSS, JS**
2. Copiez le contenu de `index.html` dans le fichier index.html
3. Créez un fichier `app.jsx` et copiez-y le contenu
4. Appuyez sur **"Run"**

## 📖 Guide d'Utilisation

### Premier lancement

1. **Importez vos données** : Cliquez sur "📥 Importer Excel" et sélectionnez votre fichier Gestion_V1.xlsx
2. **Vérifiez les données** : Allez dans "👥 Tous les clients" pour voir vos clients importés
3. **Configurez les coûts** : Allez dans "⚙️ Paramètres" pour ajuster les coûts Meta et Done

### Ajouter un client

1. Cliquez sur **"+ Nouveau Client"**
2. Remplissez le formulaire :
   - Nom (obligatoire)
   - Secteur (Horeca, Fitness, etc.)
   - Site web
   - Statut (Lead, Prospect, Client, Churned)
   - Finances (montant, abonnement, coûts)
3. Cliquez sur **"Ajouter"**

### Gérer le pipeline

1. Allez dans **"🎯 Pipeline"**
2. **Drag & Drop** : Glissez-déposez les cartes entre les colonnes
3. **Cliquez** sur une carte pour modifier les détails

### Suivre vos performances

1. Allez dans **"📊 Dashboard"**
2. Consultez vos KPIs :
   - MRR et ARR
   - Chiffre d'affaires total
   - Marge
   - Nombre de clients par statut
3. Visualisez le graphique du CA par secteur
4. Vérifiez vos objectifs de croissance

## 💾 Sauvegarde des Données

### Automatique
Les données sont **automatiquement sauvegardées** dans le navigateur (localStorage) à chaque modification.

### Export manuel
Cliquez sur **"📤 Exporter"** pour télécharger un fichier Excel avec toutes vos données.

### Import
Cliquez sur **"📥 Importer Excel"** pour charger des données depuis un fichier Excel.

## 🎨 Design

L'application utilise un design moderne "Digital Agency" avec :
- **Palette** : Slate foncé + accents orange/amber
- **Typographie** : DM Sans + Syne
- **Animations** : Transitions fluides et micro-interactions
- **Responsive** : Fonctionne sur mobile, tablette et desktop

## 📊 Structure des Données

### Client
```javascript
{
  id: number,
  name: string,
  site: string,
  secteur: string,
  status: 'lead' | 'prospect' | 'client' | 'churned',
  source: 'Out' | 'In',
  contacted: boolean,
  called: boolean,
  sold: boolean,
  montant: number,
  abonnement: number,
  coutReplit: number,
  coutDomaine: number,
  autresCouts: number,
  notes: string,
  dateAdded: string
}
```

## 🔧 Technologies

- **React 18** : Interface utilisateur
- **Chart.js** : Graphiques
- **SheetJS** : Import/Export Excel
- **Tailwind CSS** : Styling
- **LocalStorage** : Persistance des données

## 📱 Compatibilité

- ✅ Chrome, Firefox, Safari, Edge (dernières versions)
- ✅ Mobile (iOS, Android)
- ✅ Tablette
- ✅ Desktop

## 🆘 Support

### Problèmes courants

**Les données ne se sauvegardent pas**
- Vérifiez que le localStorage n'est pas désactivé dans votre navigateur
- Assurez-vous de ne pas être en navigation privée

**L'import Excel ne fonctionne pas**
- Vérifiez que le fichier est bien au format .xlsx
- Assurez-vous que la structure du fichier correspond au format attendu

**Le graphique ne s'affiche pas**
- Rafraîchissez la page (F5)
- Vérifiez que vous avez des clients avec des montants de vente

### Réinitialisation

Pour remettre l'application à zéro :
1. Allez dans **"⚙️ Paramètres"**
2. Cliquez sur **"🗑️ Réinitialiser toutes les données"**
3. Confirmez l'action

## 🚀 Améliorations Futures

- [ ] Authentification utilisateur
- [ ] Base de données cloud
- [ ] Notifications et alertes
- [ ] Rapports PDF exportables
- [ ] Intégration e-mail
- [ ] API pour connexions externes

## 📄 Licence

© 2026 DoneCRM - Tous droits réservés

---

**Made with ❤️ for Done Agency**

Pour toute question : contact@madebydone.be
